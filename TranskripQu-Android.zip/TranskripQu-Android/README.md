# TranskripQu (Android)

Aplikasi Android (WebView) untuk mengubah suara menjadi teks, Bahasa Indonesia dan Arab.

## Build APK lewat GitHub
1. Unggah seluruh isi folder ini ke repositori GitHub (termasuk folder `.github`).
2. Buka tab **Actions** → **Build APK** → tunggu hingga selesai (sekitar 3–5 menit).
3. Unduh **TranskripQu-APK** di bagian *Artifacts*, ekstrak, lalu pasang `app-debug.apk` di HP.

## Catatan
- Butuh internet dan layanan suara Google di HP.
- Hasil rekaman disimpan ke folder **Unduhan** (Download).
